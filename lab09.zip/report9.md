---
## Front matter
title: "Лабораторная работа №9"
author: "Михайлова Регина Алексеевна"

## Generic otions
lang: ru-RU
toc-title: "Содержание"

## Bibliography
bibliography: bib/cite.bib
csl: pandoc/csl/gost-r-7-0-5-2008-numeric.csl

## Pdf output format
toc: true # Table of contents
toc-depth: 2
lof: true # List of figures
lot: false # List of tables
fontsize: 12pt
linestretch: 1.5
papersize: a4
documentclass: scrreprt
## I18n polyglossia
polyglossia-lang:
  name: russian
  options:
	- spelling=modern
	- babelshorthands=true
polyglossia-otherlangs:
  name: english
## I18n babel
babel-lang: russian
babel-otherlangs: english
## Fonts
mainfont: PT Serif
romanfont: PT Serif
sansfont: PT Sans
monofont: PT Mono
mainfontoptions: Ligatures=TeX
romanfontoptions: Ligatures=TeX
sansfontoptions: Ligatures=TeX,Scale=MatchLowercase
monofontoptions: Scale=MatchLowercase,Scale=0.9
## Biblatex
biblatex: true
biblio-style: "gost-numeric"
biblatexoptions:
  - parentracker=true
  - backend=biber
  - hyperref=auto
  - language=auto
  - autolang=other*
  - citestyle=gost-numeric
## Pandoc-crossref LaTeX customization
figureTitle: "Рис."
tableTitle: "Таблица"
listingTitle: "Листинг"
lofTitle: "Список иллюстраций"
lotTitle: "Список таблиц"
lolTitle: "Листинги"
## Misc options
indent: true
header-includes:
  - \usepackage{indentfirst}
  - \usepackage{float} # keep figures where there are in the text
  - \floatplacement{figure}{H} # keep figures where there are in the text
---

# Цель работы

Приобретение практических навыков по установке и простейшему конфигурированию POP3/IMAP-сервера.
  
# Выполнение лабораторной работы

### 1. Установка Dovecot
На виртуальной машине **server** вошла под своим пользователем и перешла в режим суперпользователя:
```
sudo -i
```

Установила необходимые пакеты:
```
dnf -y install dovecot telnet
```

---

### 2. Настройка Dovecot

#### 2.1. Конфигурация протоколов
В файле `/etc/dovecot/dovecot.conf` указала:
```
protocols = imap pop3
```

![Содержимое](image/1.png){#fig:001}

#### 2.2. Настройка аутентификации
В файле `/etc/dovecot/conf.d/10-auth.conf` проверила метод аутентификации:
```
auth_mechanisms = plain
```

![Содержимое](image/2.png){#fig:002}


В файле `/etc/dovecot/conf.d/auth-system.conf.ext` убедилась, что используются PAM и passwd:
```
passdb {
  driver = pam
}
userdb {
  driver = passwd
}
```

![Содержимое](image/3.png){#fig:003}

#### 2.3. Настройка почтовых ящиков
В файле `/etc/dovecot/conf.d/10-mail.conf` указала расположение ящиков:
```
mail_location = maildir:~/Maildir
```

![Содержимое](image/4.png){#fig:004}

#### 2.4. Настройка Postfix
Задала каталог для доставки почты:
```
postconf -e 'home_mailbox = Maildir/'
```

#### 2.5. Настройка межсетевого экрана
Разрешила работу протоколов POP3 и IMAP:
```
firewall-cmd --add-service=pop3 --permanent
firewall-cmd --add-service=pop3s --permanent
firewall-cmd --add-service=imap --permanent
firewall-cmd --add-service=imaps --permanent
firewall-cmd --reload
```

![Команды](image/5.png){#fig:005}

#### 2.6. SELinux и перезапуск служб
```
restorecon -vR /etc
systemctl restart postfix
systemctl enable dovecot
systemctl start dovecot
```

---

### 3. Проверка работы Dovecot

#### 3.1. Мониторинг логов
В отдельном терминале запустила:
```
tail -f /var/log/maillog
```

#### 3.2. Проверка почты на сервере
Посмотрела письма через:
```
MAIL=~/Maildir mail
```

Также просмотрела список ящиков:
```
doveadm mailbox list -u user
```

![Команды](image/6.png){#fig:006}

#### 3.3. Настройка клиента на машине client
На клиентской машине:
```
sudo -i
dnf -y install evolution
```

В почтовом клиенте **Evolution**:
- Указала имя и адрес в формате `user@user.net`
- IMAP-сервер и SMTP-сервер: `mail.user.net`
- Порты: IMAP — 143, SMTP — 25  
- SSL: STARTTLS для IMAP, без SSL для SMTP  
- Метод аутентификации — обычный пароль  

![Evolution](image/7.png){#fig:007}

![Evolution](image/8.png){#fig:008}

![Evolution](image/9.png){#fig:009}

Отправила несколько тестовых писем самой себе — доставка прошла успешно.  
При этом в логе на сервере (`tail -f /var/log/maillog`) отобразились соответствующие сообщения о приеме и доставке писем.

![Тестовые письма](image/10.png){#fig:010}

![Тестовые письма](image/11.png){#fig:011}

![Тестовые письма](image/12.png){#fig:012}

![Тестовые письма](image/13.png){#fig:013}

![Тестовые письма](image/14.png){#fig:014}

---

### 4. Проверка через Telnet

Подключилась к серверу:
```
telnet mail.user.net 110
```

Ввела:
```
user имя_пользователя
pass мой_пароль
```

Проверила список писем:
```
list
```

Просмотрела первое письмо:
```
retr 1
```

Удаление второго письма:
```
dele 2
```

Выход:
```
quit
```

Результат — почтовая служба функционирует корректно, письма читаются и удаляются через POP3.

![Telnet](image/15.png){#fig:015}

---

### 5. Внесение изменений в окружение Vagrant

Перешла в каталог:
```
cd /vagrant/provision/server
mkdir -p /vagrant/provision/server/mail/etc/dovecot/conf.d
```

Скопировала конфигурационные файлы:
```
cp -R /etc/dovecot/dovecot.conf /vagrant/provision/server/mail/etc/dovecot/
cp -R /etc/dovecot/conf.d/10-auth.conf /vagrant/provision/server/mail/etc/dovecot/conf.d/
cp -R /etc/dovecot/conf.d/auth-system.conf.ext /vagrant/provision/server/mail/etc/dovecot/conf.d/
cp -R /etc/dovecot/conf.d/10-mail.conf /vagrant/provision/server/mail/etc/dovecot/conf.d/
```

Добавила в файл `/vagrant/provision/server/mail.sh`:
- Установку Dovecot и Telnet  
- Настройку межсетевого экрана  
- Настройку Postfix (Maildir)  
- Перезапуск Postfix и запуск Dovecot  

![server](image/16.png){#fig:016}

На машине client отредактировала `/vagrant/provision/client/mail.sh`:
```
dnf -y install evolution
```
![client](image/17.png){#fig:017}


# Вывод:  
  
В ходе выполнения лабораторной работы я приобрела практические навыки по установке и простейшему конфигурированию POP3/IMAP-сервера.

 